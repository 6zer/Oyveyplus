# OyVeyPlus
Custom Base continuation of OyVey (a phobos skid lel)

please note that some of the current modules are skidded. This is because i was testing out rendering modules. 
also some of the modules do not work and are currently being fixxed - so if u try and build it then half of the modules will justt  crash ur game. 

TODO list:

Rewrite most of the modules,
add a working command system,
add more commands,
rewrite scaffold,
rewrite trajectories (its ass and dont work),
visualrange fix

Modules that will be added:
SelfTrap,
AutoTrap,
BedAura(maybe)
anything from the suggestions channel in our discord

Discord invite if u have any questions about the client then ask them in here :
https://discord.gg/5bpvnPafKd
