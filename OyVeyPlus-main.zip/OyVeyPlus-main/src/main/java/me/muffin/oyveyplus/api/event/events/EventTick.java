package me.muffin.oyveyplus.api.event.events;

import me.muffin.oyveyplus.api.event.Event;

/**
 * @author fuckyouthinkimboogieman
 */

public class EventTick extends Event {

}
