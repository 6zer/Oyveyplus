package me.muffin.oyveyplus.api.utils;

import java.awt.*;

public class Colors {

	public Color fore;
	public Color back;
	public Color font;

	public Colors(Color fore, Color back, Color font) {
		this.fore = fore;
		this.back = back;
		this.font = font;
	}

}
