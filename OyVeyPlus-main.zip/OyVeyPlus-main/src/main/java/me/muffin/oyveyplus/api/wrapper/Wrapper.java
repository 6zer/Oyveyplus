package me.muffin.oyveyplus.api.wrapper;

import net.minecraft.client.Minecraft;

public interface Wrapper { Minecraft mc = Minecraft.getMinecraft(); }
