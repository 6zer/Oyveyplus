package me.muffin.oyveyplus.impl.gui.click;

import me.muffin.oyveyplus.api.wrapper.Wrapper;

public class Component implements Wrapper {

    public void render() {}

    public void updateComponent(double mouseX, double mouseY) {}

    public void mouseClicked(double mouseX, double mouseY, int button) {}

    public void mouseReleased( double mouseX,  double mouseY,  int mouseButton) {}

    public void keyTyped(int key) {}

    public void setOffset(int offset) {}

    public int getHeight() { return 0; }

}
