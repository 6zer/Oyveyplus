package me.zero.alpine.event;

/**
 * The state of an event
 *
 * @author Brady
 * @since 2/10/2017
 */
public enum EventState {

    PRE, POST
}
